
<?php $__env->startSection('content'); ?>
<br><br>
<div class="card">
    <div class="card-header">Productos - Editar</div>
    <div class="card-body">
        <form action="/productoactualizar" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
                <input type="text" name="id" id="id" style="display: none;" value="<?php echo e($producto[0]->id); ?>"/>
                <input type="text" name="codigo" class="form-control" placeholder="Código" value="<?php echo e($producto[0]->codigo); ?>" aria-label="Recipient's username" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Código Producto</span>
            </div>
            <div class="input-group mb-3">
                <input type="text" name="nombre" class="form-control" placeholder="Nombre" value="<?php echo e($producto[0]->nombre); ?>" aria-label="Recipient's username" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Nombre Producto</span>
            </div>
            <div class="input-group mb-3">
                <input type="text" name="descripcion" class="form-control" placeholder="Descripcion del Producto" value="<?php echo e($producto[0]->descripcion); ?>" aria-label="Descripcion de la Categoria" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Descripcion del Producto</span>
            </div>
            <div class="input-group mb-3">
                <select name="categoria" id="categoria_container" class="form-control" require>
                    <option selected="selected" class="input-group-text">Eliga una categoría</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" class="input-group-text"><?php echo e($categoria->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="input-group-text" id="basic-addon2">Categoria Producto</span>
            </div>
            <input class="btn btn-primary" type="submit" value="Guardar Cambios">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Intr4Snak3\Documents\clases\4to Semestre\Desarrollo de Aplicaciones WEB\Laravel\primer-proyecto\resources\views/productoeditar.blade.php ENDPATH**/ ?>