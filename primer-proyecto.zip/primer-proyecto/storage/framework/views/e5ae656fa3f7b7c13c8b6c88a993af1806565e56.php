
<?php $__env->startSection('content'); ?>
<br><br>
<div class="card">
    <div class="card-header">Productos</div>
    <div class="card-body">
        <form action="/productocrear" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
                <input type="text" name="codigo" class="form-control" placeholder="Código" aria-label="Recipient's username" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Código Producto</span>
            </div>
            <div class="input-group mb-3">
                <input type="text" name="nombre" class="form-control" placeholder="Nombre" aria-label="Recipient's username" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Nombre Producto</span>
            </div>
            <div class="input-group mb-3">
                <input type="text" name="descripcion" class="form-control" placeholder="Descripcion del Producto" aria-label="Descripcion de la Categoria" aria-describedby="basic-addon2" require>
                <span class="input-group-text" id="basic-addon2">Descripcion del Producto</span>
            </div>
            <div class="input-group mb-3">
                <select name="categoria" id="categoria_container" class="form-control" require>
                    <option selected="selected" class="input-group-text">Eliga una categoría</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" class="input-group-text"><?php echo e($categoria->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="input-group-text" id="basic-addon2">Categoria Producto</span>
            </div>
            <input class="btn btn-primary" type="submit" value="crear">
        </form>
    </div>
</div>
<br><br>
<h2>Listado Productos</h2>
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">Código</th>
                <th scope="col">Nombre</th>
                <th scope="col">Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->codigo); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td>
                    <a href="/productoeditar/<?php echo e($producto->id); ?>" class="btn btn-success">Editar</a>
                    <a href="/productoeliminar/<?php echo e($producto->id); ?>" class="btn btn-danger">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Intr4Snak3\Documents\clases\4to Semestre\Desarrollo de Aplicaciones WEB\Laravel\primer-proyecto\resources\views/productonuevo.blade.php ENDPATH**/ ?>