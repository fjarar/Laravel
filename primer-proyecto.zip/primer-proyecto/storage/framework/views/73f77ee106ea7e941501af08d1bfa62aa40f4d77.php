
<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="card">
    <div class="card-header">Categorías - Editar</div>
    <div class="card-body">
        <form action="/categoriaactualizar" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
            <input type="text" name="id" id="id" style="display:none" value="<?php echo e($categoria[0]->id); ?>">
            <input type="text" name="nombre" class="form-control" placeholder="Nombre" value="<?php echo e($categoria[0]->nombre); ?>">
            <span class="input-group-text" id="basic-addon2">Nombre Categoría</span>
            </div>
            <div class="input-group mb-3">
            <input type="text" name="descripcion" class="form-control" placeholder="Descripción de la categoría" value="<?php echo e($categoria[0]->descripcion); ?>">
            <span class="input-group-text" id="basic-addon2">Descripción</span>
            </div>
            <input class="btn btn-primary" type="submit" value="Guardar Cambios">
        </form>   
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Intr4Snak3\Documents\clases\4to Semestre\Desarrollo de Aplicaciones WEB\Laravel\primer-proyecto\resources\views/categoriaeditar.blade.php ENDPATH**/ ?>